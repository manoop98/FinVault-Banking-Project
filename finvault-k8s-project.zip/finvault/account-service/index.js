const express = require('express');
const { Pool } = require('pg');
const axios = require('axios');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const pool = new Pool({
  host: process.env.DB_HOST || 'postgres-service',
  port: process.env.DB_PORT || 5432,
  database: process.env.DB_NAME || 'finvault',
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres123',
});

const AUTH_SERVICE_URL = process.env.AUTH_SERVICE_URL || 'http://auth-service:3001';

// Initialize DB tables
async function initDB() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS accounts (
      id SERIAL PRIMARY KEY,
      user_id INTEGER NOT NULL,
      account_number VARCHAR(20) UNIQUE NOT NULL,
      account_type VARCHAR(20) DEFAULT 'checking',
      balance DECIMAL(15,2) DEFAULT 0.00,
      currency VARCHAR(3) DEFAULT 'USD',
      created_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS transactions (
      id SERIAL PRIMARY KEY,
      account_id INTEGER REFERENCES accounts(id),
      type VARCHAR(20) NOT NULL,
      amount DECIMAL(15,2) NOT NULL,
      description VARCHAR(255),
      reference VARCHAR(50) UNIQUE,
      balance_after DECIMAL(15,2),
      created_at TIMESTAMP DEFAULT NOW()
    );
  `);
  console.log('✅ Account DB initialized');
}

// Middleware: verify JWT with auth-service
async function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer '))
    return res.status(401).json({ error: 'No token provided' });

  const token = authHeader.split(' ')[1];
  try {
    const response = await axios.post(`${AUTH_SERVICE_URL}/auth/verify`, { token });
    if (!response.data.valid) return res.status(401).json({ error: 'Invalid token' });
    req.user = response.data.user;
    next();
  } catch {
    res.status(401).json({ error: 'Auth service unavailable' });
  }
}

// Generate account number
function generateAccountNumber() {
  return 'FV' + Date.now().toString().slice(-8) + Math.floor(Math.random() * 100);
}

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'account-service', timestamp: new Date() });
});

// Create account
app.post('/accounts', authenticate, async (req, res) => {
  try {
    const { account_type = 'checking', initial_deposit = 0 } = req.body;
    const accountNumber = generateAccountNumber();

    const result = await pool.query(
      `INSERT INTO accounts (user_id, account_number, account_type, balance)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [req.user.userId, accountNumber, account_type, initial_deposit]
    );

    const account = result.rows[0];

    // Record opening deposit
    if (initial_deposit > 0) {
      const ref = 'OPEN-' + Date.now();
      await pool.query(
        `INSERT INTO transactions (account_id, type, amount, description, reference, balance_after)
         VALUES ($1, 'credit', $2, 'Account opening deposit', $3, $4)`,
        [account.id, initial_deposit, ref, initial_deposit]
      );
    }

    res.status(201).json(account);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create account' });
  }
});

// Get my accounts
app.get('/accounts', authenticate, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM accounts WHERE user_id = $1 ORDER BY created_at DESC',
      [req.user.userId]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch accounts' });
  }
});

// Get account by ID
app.get('/accounts/:id', authenticate, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM accounts WHERE id = $1 AND user_id = $2',
      [req.params.id, req.user.userId]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'Account not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch account' });
  }
});

// Deposit
app.post('/accounts/:id/deposit', authenticate, async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { amount, description = 'Deposit' } = req.body;
    if (!amount || amount <= 0) return res.status(400).json({ error: 'Invalid amount' });

    const accResult = await client.query(
      'SELECT * FROM accounts WHERE id = $1 AND user_id = $2 FOR UPDATE',
      [req.params.id, req.user.userId]
    );
    if (!accResult.rows[0]) return res.status(404).json({ error: 'Account not found' });

    const newBalance = parseFloat(accResult.rows[0].balance) + parseFloat(amount);
    await client.query('UPDATE accounts SET balance = $1 WHERE id = $2', [newBalance, req.params.id]);

    const ref = 'DEP-' + Date.now();
    const tx = await client.query(
      `INSERT INTO transactions (account_id, type, amount, description, reference, balance_after)
       VALUES ($1, 'credit', $2, $3, $4, $5) RETURNING *`,
      [req.params.id, amount, description, ref, newBalance]
    );

    await client.query('COMMIT');
    res.json({ transaction: tx.rows[0], new_balance: newBalance });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: 'Deposit failed' });
  } finally {
    client.release();
  }
});

// Withdraw
app.post('/accounts/:id/withdraw', authenticate, async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { amount, description = 'Withdrawal' } = req.body;
    if (!amount || amount <= 0) return res.status(400).json({ error: 'Invalid amount' });

    const accResult = await client.query(
      'SELECT * FROM accounts WHERE id = $1 AND user_id = $2 FOR UPDATE',
      [req.params.id, req.user.userId]
    );
    if (!accResult.rows[0]) return res.status(404).json({ error: 'Account not found' });
    if (parseFloat(accResult.rows[0].balance) < amount)
      return res.status(400).json({ error: 'Insufficient funds' });

    const newBalance = parseFloat(accResult.rows[0].balance) - parseFloat(amount);
    await client.query('UPDATE accounts SET balance = $1 WHERE id = $2', [newBalance, req.params.id]);

    const ref = 'WDR-' + Date.now();
    const tx = await client.query(
      `INSERT INTO transactions (account_id, type, amount, description, reference, balance_after)
       VALUES ($1, 'debit', $2, $3, $4, $5) RETURNING *`,
      [req.params.id, amount, description, ref, newBalance]
    );

    await client.query('COMMIT');
    res.json({ transaction: tx.rows[0], new_balance: newBalance });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: 'Withdrawal failed' });
  } finally {
    client.release();
  }
});

// Get transactions
app.get('/accounts/:id/transactions', authenticate, async (req, res) => {
  try {
    const accResult = await pool.query(
      'SELECT id FROM accounts WHERE id = $1 AND user_id = $2',
      [req.params.id, req.user.userId]
    );
    if (!accResult.rows[0]) return res.status(404).json({ error: 'Account not found' });

    const result = await pool.query(
      'SELECT * FROM transactions WHERE account_id = $1 ORDER BY created_at DESC LIMIT 50',
      [req.params.id]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch transactions' });
  }
});

const PORT = process.env.PORT || 3002;
initDB().then(() => {
  app.listen(PORT, () => console.log(`🏦 Account service running on port ${PORT}`));
});
