# FinVault on Kubernetes — Complete Deployment Guide

## Architecture Overview

```
                         ┌─────────────────────────────────────────────┐
                         │           Kubernetes Cluster                 │
                         │                                              │
 User Browser            │  ┌──────────────────────────────────────┐   │
     │                   │  │  Namespace: finvault                 │   │
     │ HTTPS             │  │                                      │   │
     ▼                   │  │  ┌──────────┐   ┌────────────────┐  │   │
 ┌──────────┐  HTTP/443  │  │  │  Ingress │──▶│    Frontend    │  │   │
 │  Internet│───────────▶│  │  │  (nginx) │   │  (Nginx+React) │  │   │
 │  Traffic │            │  │  └──────────┘   │   2 replicas   │  │   │
 └──────────┘            │  │                 └───────┬────────┘  │   │
                         │  │                         │            │   │
                         │  │              /api/auth  │ /api/acct  │   │
                         │  │                ┌────────┴────────┐   │   │
                         │  │                ▼                 ▼   │   │
                         │  │  ┌─────────────────┐  ┌──────────────┐  │
                         │  │  │  auth-service   │  │acct-service  │  │
                         │  │  │  2 replicas     │  │ 2 replicas   │  │
                         │  │  │  port: 3001     │  │ port: 3002   │  │
                         │  │  └────────┬────────┘  └──────┬───────┘  │
                         │  │           │                   │          │
                         │  │           └──────────┬────────┘          │
                         │  │                      ▼                   │
                         │  │           ┌─────────────────┐            │
                         │  │           │   PostgreSQL     │            │
                         │  │           │   StatefulSet   │            │
                         │  │           │   port: 5432    │            │
                         │  │           │   5Gi PVC       │            │
                         │  │           └─────────────────┘            │
                         │  └──────────────────────────────────────────┘
                         └─────────────────────────────────────────────┘

K8s Objects Used:
  Namespace          → isolates all FinVault resources
  ConfigMap          → non-sensitive env vars (DB_HOST, service URLs)
  Secret             → passwords, JWT keys (base64 encoded)
  PersistentVolume   → actual disk storage for Postgres
  PersistentVolumeClaim → pod's "claim" to that storage
  StatefulSet        → manages Postgres (stable identity + persistent storage)
  Deployment         → manages stateless services (auth, account, frontend)
  Service (ClusterIP) → internal pod-to-pod networking
  Service (LoadBalancer) → external access to frontend
  Ingress            → HTTP routing rules + TLS termination
  HPA                → auto-scales pods based on CPU/memory
  initContainers     → health-check dependencies before startup
```

---

## File Structure

```
finvault/
├── auth-service/
│   ├── index.js          ← Express app (register, login, verify JWT)
│   ├── package.json
│   └── Dockerfile        ← Multi-stage, non-root user
│
├── account-service/
│   ├── index.js          ← Express app (accounts, deposit, withdraw, transactions)
│   ├── package.json
│   └── Dockerfile
│
├── frontend/
│   ├── index.html        ← Full banking SPA (vanilla JS)
│   ├── nginx.conf        ← Reverse proxy /api/* to microservices
│   └── Dockerfile
│
├── k8s/
│   ├── base/
│   │   ├── namespace.yaml       ← K8s namespace
│   │   ├── configmap.yaml       ← Shared env config
│   │   └── secrets.yaml         ← DB password + JWT secret
│   ├── storage/
│   │   └── postgres-storage.yaml ← PV + PVC
│   ├── services/
│   │   ├── postgres.yaml         ← StatefulSet + ClusterIP Service
│   │   ├── auth-service.yaml     ← Deployment + ClusterIP Service
│   │   ├── account-service.yaml  ← Deployment + ClusterIP Service
│   │   └── frontend.yaml         ← Deployment + LoadBalancer Service
│   ├── ingress/
│   │   └── ingress.yaml          ← Ingress rules + TLS
│   └── monitoring/
│       └── hpa.yaml              ← HPA for all 3 services
│
└── docker-compose.yml    ← Local dev (mirrors K8s setup)
```

---

## Step-by-Step Deployment

### Prerequisites

```bash
# Verify tools are installed
kubectl version --client
docker --version
minikube version   # or any K8s cluster
```

---

### OPTION A — Local Testing with Docker Compose

```bash
# 1. Clone / navigate to project root
cd finvault

# 2. Build and start all services
docker compose up --build

# 3. Access the app
open http://localhost:8080
```

---

### OPTION B — Full Kubernetes Deployment

#### Step 1 — Start your Kubernetes cluster

```bash
# Minikube (local)
minikube start --memory=4096 --cpus=4

# OR use any cloud cluster:
# Azure AKS:  az aks get-credentials --resource-group rg-finvault --name aks-finvault
# AWS EKS:    aws eks update-kubeconfig --name finvault-cluster
# GCP GKE:    gcloud container clusters get-credentials finvault-cluster

# Verify connection
kubectl cluster-info
kubectl get nodes
```

#### Step 2 — Build and push Docker images

```bash
# Log in to your container registry
docker login                             # Docker Hub
# OR: az acr login --name yourregistry  # Azure Container Registry

REGISTRY="yourdockerhub/finvault"        # Change this!

# Build all images
docker build -t $REGISTRY-auth:latest ./auth-service
docker build -t $REGISTRY-account:latest ./account-service
docker build -t $REGISTRY-frontend:latest ./frontend

# Push to registry
docker push $REGISTRY-auth:latest
docker push $REGISTRY-account:latest
docker push $REGISTRY-frontend:latest
```

#### Step 3 — Update image names in deployment files

```bash
# Replace placeholder image names with your actual registry
sed -i 's|your-registry/finvault-auth|yourdockerhub/finvault-auth|g' k8s/services/auth-service.yaml
sed -i 's|your-registry/finvault-account|yourdockerhub/finvault-account|g' k8s/services/account-service.yaml
sed -i 's|your-registry/finvault-frontend|yourdockerhub/finvault-frontend|g' k8s/services/frontend.yaml
```

#### Step 4 — Apply K8s manifests in order

```bash
# 4a. Create namespace first (everything lives here)
kubectl apply -f k8s/base/namespace.yaml

# Verify
kubectl get namespace finvault

# 4b. Apply config (ConfigMap and Secrets)
kubectl apply -f k8s/base/configmap.yaml
kubectl apply -f k8s/base/secrets.yaml

# Verify
kubectl get configmap -n finvault
kubectl get secret -n finvault

# 4c. Create storage (PV + PVC)
kubectl apply -f k8s/storage/postgres-storage.yaml

# Verify — PVC should show "Bound"
kubectl get pv,pvc -n finvault

# 4d. Deploy PostgreSQL first
kubectl apply -f k8s/services/postgres.yaml

# Wait for Postgres to be ready
kubectl rollout status statefulset/postgres -n finvault

# Verify
kubectl get pods -n finvault -l component=postgres

# 4e. Deploy microservices
kubectl apply -f k8s/services/auth-service.yaml
kubectl apply -f k8s/services/account-service.yaml

# Wait for both to be ready
kubectl rollout status deployment/auth-service -n finvault
kubectl rollout status deployment/account-service -n finvault

# 4f. Deploy frontend
kubectl apply -f k8s/services/frontend.yaml
kubectl rollout status deployment/frontend -n finvault

# 4g. Install Ingress Controller (if not already installed)
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/cloud/deploy.yaml

# Wait for ingress controller
kubectl wait --namespace ingress-nginx \
  --for=condition=ready pod \
  --selector=app.kubernetes.io/component=controller \
  --timeout=120s

# 4h. Apply Ingress rules
kubectl apply -f k8s/ingress/ingress.yaml

# 4i. Install metrics-server for HPA
kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml

# Apply HPA
kubectl apply -f k8s/monitoring/hpa.yaml
```

#### Step 5 — Verify everything is running

```bash
# See all resources in finvault namespace
kubectl get all -n finvault

# Expected output:
# NAME                                    READY   STATUS    RESTARTS
# pod/auth-service-xxx-xxx                1/1     Running   0
# pod/auth-service-yyy-yyy                1/1     Running   0
# pod/account-service-xxx-xxx             1/1     Running   0
# pod/account-service-yyy-yyy             1/1     Running   0
# pod/frontend-xxx-xxx                    1/1     Running   0
# pod/frontend-yyy-yyy                    1/1     Running   0
# pod/postgres-0                          1/1     Running   0
#
# NAME                       TYPE           EXTERNAL-IP
# service/postgres-service   ClusterIP      <none>
# service/auth-service       ClusterIP      <none>
# service/account-service    ClusterIP      <none>
# service/frontend-service   LoadBalancer   20.100.x.x   ← your public IP

# Check HPA status
kubectl get hpa -n finvault

# Check ingress
kubectl get ingress -n finvault
```

#### Step 6 — Access the application

```bash
# Cloud (LoadBalancer) — get external IP
kubectl get service frontend-service -n finvault
# Open: http://<EXTERNAL-IP>

# Minikube — use tunnel
minikube tunnel
# Then open: http://localhost:80
# OR use minikube service:
minikube service frontend-service -n finvault --url
```

---

## Key Kubernetes Concepts in This Project

### 1. Namespace
Isolates all FinVault resources from other apps on the cluster.
```bash
kubectl get all -n finvault   # -n flag = namespace
```

### 2. ConfigMap vs Secret
```bash
# ConfigMap — plain text config
kubectl describe configmap finvault-config -n finvault

# Secret — base64 encoded (not encrypted by default, use Vault in prod)
kubectl get secret finvault-secrets -n finvault -o jsonpath='{.data.DB_PASSWORD}' | base64 -d
```

### 3. Deployment vs StatefulSet
```
Deployment  → stateless apps (auth, account, frontend)
             - Pods are interchangeable
             - Any replica can handle any request
StatefulSet → stateful apps (postgres)
             - Pods have stable names (postgres-0)
             - Ordered startup/shutdown
             - Each pod has its own PVC
```

### 4. Service Types
```
ClusterIP    → internal only (postgres, auth, account)
LoadBalancer → external IP from cloud provider (frontend)
NodePort     → exposes on node IP:port (testing only)
```

### 5. initContainers
Services wait for dependencies using initContainers before the main container starts. This prevents "connection refused" errors on startup.

### 6. Health Probes
```yaml
readinessProbe  → "is this pod ready to receive traffic?" (removes from LB if not)
livenessProbe   → "is this pod alive?" (restarts it if not)
```

---

## Useful Debugging Commands

```bash
# Watch pods in real time
kubectl get pods -n finvault -w

# See pod logs
kubectl logs -f deployment/auth-service -n finvault
kubectl logs -f deployment/account-service -n finvault
kubectl logs -f deployment/frontend -n finvault
kubectl logs -f statefulset/postgres -n finvault

# Describe a pod (shows events, errors)
kubectl describe pod <pod-name> -n finvault

# Execute into a running pod
kubectl exec -it deployment/auth-service -n finvault -- sh
kubectl exec -it statefulset/postgres -n finvault -- psql -U postgres -d finvault

# Port-forward for local testing (bypass Ingress/LoadBalancer)
kubectl port-forward service/frontend-service 8080:80 -n finvault
kubectl port-forward service/auth-service 3001:3001 -n finvault

# Scale manually
kubectl scale deployment auth-service --replicas=4 -n finvault

# Rolling restart (re-pulls image)
kubectl rollout restart deployment/auth-service -n finvault

# Check HPA is scaling
kubectl describe hpa auth-service-hpa -n finvault
```

---

## Update / Redeploy a Service

```bash
# 1. Build and push new image
docker build -t yourdockerhub/finvault-auth:v2 ./auth-service
docker push yourdockerhub/finvault-auth:v2

# 2. Update the deployment (zero-downtime rolling update)
kubectl set image deployment/auth-service \
  auth-service=yourdockerhub/finvault-auth:v2 \
  -n finvault

# 3. Watch the rollout
kubectl rollout status deployment/auth-service -n finvault

# 4. Rollback if something goes wrong
kubectl rollout undo deployment/auth-service -n finvault
```

---

## Teardown

```bash
# Delete everything in the namespace
kubectl delete namespace finvault

# Stop minikube
minikube stop
```
